
public class BSTNode1 <K extends Comparable<K>> {
	public K key;
	public BSTNode1<K> left;
	public BSTNode1<K> right;
	
	public BSTNode1(K k) {
		key = k;
	}

}
