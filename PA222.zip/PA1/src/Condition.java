public interface Condition {
	boolean test(Array<Object> row);
}
